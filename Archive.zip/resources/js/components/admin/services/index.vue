<template>
  <router-view/>
</template>
<script>
export default {
	// mounted() {
	// 	this.$router.replace({
  //     name: 'service-home'
  //   })
	// }
}
</script>