@extends('admin.template')

@section('admin-content')
	<h1>Hello World</h1>
{{--	<article-index edit-url="{{url('dashboard/articles/edit')}}" />--}}
@stop