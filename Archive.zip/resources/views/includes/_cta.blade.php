<section class="ftco-intro" style="background-image: url(/assets/front/images/bg_3.jpg);" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <h2>We are always here to provide you with a world-class fertility treatments. </h2>
                <p class="mb-0">Your Health is Our Top Priority with Comprehensive, Affordable medical.</p>
                <p></p>
            </div>
            <div class="col-md-3 d-flex align-items-center">
                <p class="mb-0"><a href="/#section-counter" class="btn btn-secondary px-4 py-3">Book an Appointment</a></p>
            </div>
        </div>
    </div>
</section>
