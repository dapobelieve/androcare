<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-migrate/3.0.1/jquery-migrate.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.4.4/umd/popper.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/js/bootstrap.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/jquery.waypoints.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/stellar.js/0.6.2/jquery.stellar.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/aos.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-animateNumber/0.0.14/jquery.animateNumber.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/jquery.timepicker.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/scrollax.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&amp;sensor=false" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/google-map.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/main.js" type="7e700508d0afead9016b28c0-text/javascript"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script type="7e700508d0afead9016b28c0-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<script src="/assets/front/js/rocket-loader.min.js" data-cf-settings="7e700508d0afead9016b28c0-|49" defer=""></script>