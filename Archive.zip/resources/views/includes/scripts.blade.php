<script src="/assets/front/js/jquery.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/jquery-migrate-3.0.1.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/popper.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/bootstrap.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/jquery.easing.1.3.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/jquery.waypoints.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/jquery.stellar.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/owl.carousel.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/jquery.magnific-popup.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/aos.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/jquery.animateNumber.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/bootstrap-datepicker.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/jquery.timepicker.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/scrollax.min.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&amp;sensor=false" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/google-map.js" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script src="/assets/front/js/main.js" type="7e700508d0afead9016b28c0-text/javascript"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="7e700508d0afead9016b28c0-text/javascript"></script>
<script type="7e700508d0afead9016b28c0-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<script src="/assets/front/js/rocket-loader.min.js" data-cf-settings="7e700508d0afead9016b28c0-|49" defer=""></script>