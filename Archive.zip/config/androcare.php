<?php

return [
    'website' => [
    		'name' => 'Androcare Fertility Hospital',
        'phone' => '08180073995',
        'email' => 'info@androcarefertilityng.org',
				'url' => 'https://androcarefertilityng.org/',
        'address' => '1, Segun Adekoya Street, Coker Estate, Shasha, Akowonjo	Lagos',
        'logo' => 'https://res.cloudinary.com/rohing/image/upload/v1597723993/androcare/assets/logo1.png',
        'socials' => [
            'twitter' => "https://twitter.com/AndrocareCentre",
            'facebook' => 'https://web.facebook.com/androcarefertility',
            'linkedin' => 'https://www.linkedin.com/company/androcare-fertility-centre/about/',
            'instagram' => 'https://www.instagram.com/androcare_fertility/'
        ]
    ]
];
