<?php $__env->startSection('site.title'); ?>
	<title>Gallery 📸 | Androcare Fertility Nigeria </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site.styles'); ?>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.css" />
	<style>
		.gallery-block.grid-gallery{
			padding-bottom: 60px;
			padding-top: 60px;
		}

		.gallery-block.grid-gallery .heading{
			margin-bottom: 50px;
			text-align: center;
		}

		.gallery-block.grid-gallery .heading h2{
			font-weight: bold;
			font-size: 1.4rem;
			text-transform: uppercase;
		}

		.gallery-block.grid-gallery a:hover{
			opacity: 0.8;
		}

		.gallery-block.grid-gallery .item img{
			object-fit: cover;
			height: 100%;
			width: 100%;
			box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.15);
			transition: 0.4s;
		}

		.gallery-block.grid-gallery .item{
			height: 270px;
			width: 360px;
			margin-bottom: 20px;
		}

		@media (min-width: 576px) {

			.gallery-block.grid-gallery .scale-on-hover:hover{
				transform: scale(1.05);
				box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.15) !important;
			}
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<section class="hero-wrap hero-wrap-2" style="background-image: url('/assets/front/images/bg_1.jpg');" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-2 bread">Gallery 📸</h1>
					<p class="breadcrumbs">
						<span class="mr-2"><a href="index.html">Home<i class="ion-ios-arrow-forward"></i></a></span>
						<span>Gallery <i class="ion-ios-arrow-forward"></i></span>
					</p>
				</div>
			</div>
		</div>
	</section>
	<?php
		$img1 = 'https://res.cloudinary.com/rohing/image/upload/v1585572497/harley-davidson-1HZcJjdtc9g-unsplash_vwslej.jpg';
		$img2 = 'https://res.cloudinary.com/rohing/image/upload/v1587700139/photo-1542393545-10f5cde2c810_zvvwje.jpg';
	?>

	<section class="gallery-block grid-gallery">
		<div class="container">
			<div class="row">
				<?php for($i = 0; $i < 10; $i++): ?>
					<div class="col-md-6 col-lg-3 item">
						<a class="lightbox" href="<?php echo e($i % 2 == 0 ? $img1 : $img2); ?>">
							<img class="img-fluid image scale-on-hover"
									 src="<?php echo e($i % 2 == 0 ? $img1 : $img2); ?>">
						</a>
					</div>
				<?php endfor; ?>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('site.scripts'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.js"></script>
	<script>
      baguetteBox.run('.grid-gallery', { animation: 'slideIn'});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pages/gallery.blade.php ENDPATH**/ ?>