<link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="/assets/front/css/open-iconic-bootstrap.min.css">
<link rel="stylesheet" href="/assets/front/css/animate.css">
<link rel="stylesheet" href="/assets/front/css/owl.carousel.min.css">
<link rel="stylesheet" href="/assets/front/css/owl.theme.default.min.css">
<link rel="stylesheet" href="/assets/front/css/magnific-popup.css">
<link rel="stylesheet" href="/assets/front/css/aos.css">
<link rel="stylesheet" href="/assets/front/css/ionicons.min.css">
<link rel="stylesheet" href="/assets/front/css/bootstrap-datepicker.css">
<link rel="stylesheet" href="/assets/front/css/jquery.timepicker.css">
<link rel="stylesheet" href="/assets/front/css/flaticon.css">
<link rel="stylesheet" href="/assets/front/css/icomoon.css">
<link rel="stylesheet" href="/assets/front/css/style.css"><?php /**PATH /var/www/html/resources/views/includes/head.blade.php ENDPATH**/ ?>